import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/track.dart';
import '../theme/app_theme.dart';

class TrackTile extends StatelessWidget {
  final Track track;
  final bool isActive;
  final VoidCallback onTap;

  const TrackTile({super.key, required this.track, required this.onTap, this.isActive = false});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: CachedNetworkImage(
          imageUrl: track.imageUrl,
          width: 52,
          height: 52,
          fit: BoxFit.cover,
          placeholder: (_, __) => Container(width: 52, height: 52, color: AppColors.surfaceHigh),
          errorWidget: (_, __, ___) => Container(
            width: 52,
            height: 52,
            color: AppColors.surfaceHigh,
            child: const Icon(Icons.music_note, color: Colors.white24),
          ),
        ),
      ),
      title: Text(
        track.title,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: isActive ? AppColors.accent : AppColors.textPrimary,
          fontWeight: FontWeight.w600,
          fontSize: 14,
        ),
      ),
      subtitle: Text(
        track.artistName,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
      ),
      trailing: Text(track.durationLabel, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
      onTap: onTap,
    );
  }
}
