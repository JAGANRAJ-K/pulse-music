import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/track.dart';
import '../services/jamendo_api.dart';
import '../services/player_service.dart';
import '../theme/app_theme.dart';
import '../widgets/track_tile.dart';
import '../widgets/mini_player.dart';
import 'search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _api = JamendoApi();
  List<Track> _newReleases = [];
  List<Track> _popular = [];
  bool _loading = true;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _load();
    // Real-time-ish auto refresh: re-check for new releases every 10 minutes
    // while the app is open, so newly released songs appear automatically.
    _refreshTimer = Timer.periodic(const Duration(minutes: 10), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() => _loading = true);
    try {
      final results = await Future.wait([
        _api.fetchNewReleases(),
        _api.fetchPopular(),
      ]);
      if (mounted) {
        setState(() {
          _newReleases = results[0];
          _popular = results[1];
        });
      }
    } catch (_) {
      // Network hiccup — keep whatever we already have on screen.
    } finally {
      if (mounted && !silent) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final player = context.read<PlayerService>();

    return Scaffold(
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.accent,
          backgroundColor: AppColors.surface,
          onRefresh: () => _load(),
          child: _loading
              ? const Center(child: CircularProgressIndicator(color: AppColors.accent))
              : ListView(
                  padding: const EdgeInsets.only(bottom: 100),
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Discover', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                          IconButton(
                            icon: const Icon(Icons.search),
                            onPressed: () => Navigator.of(context)
                                .push(MaterialPageRoute(builder: (_) => const SearchScreen())),
                          ),
                        ],
                      ),
                    ),
                    _SectionHeader('New Releases'),
                    ..._newReleases.take(15).map((t) => TrackTile(
                          track: t,
                          onTap: () => player.playTrack(t, queueContext: _newReleases),
                        )),
                    const SizedBox(height: 12),
                    _SectionHeader('Popular Right Now'),
                    ..._popular.take(15).map((t) => TrackTile(
                          track: t,
                          onTap: () => player.playTrack(t, queueContext: _popular),
                        )),
                  ],
                ),
        ),
      ),
      bottomSheet: const MiniPlayer(),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
    );
  }
}
