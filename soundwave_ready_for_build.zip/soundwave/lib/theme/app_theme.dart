import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const background = Color(0xFF0B0B0F);
  static const surface = Color(0xFF16161D);
  static const surfaceHigh = Color(0xFF1F1F29);
  static const accent = Color(0xFF1ED760); // Spotify-green style accent
  static const accentAlt = Color(0xFFFA586A); // secondary accent (Apple-Music-ish pink/red)
  static const textPrimary = Colors.white;
  static const textSecondary = Colors.white60;
}

class AppTheme {
  static ThemeData get dark {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.accent,
        secondary: AppColors.accentAlt,
        surface: AppColors.surface,
      ),
      textTheme: GoogleFonts.plusJakartaSansTextTheme(base.textTheme).apply(
        bodyColor: AppColors.textPrimary,
        displayColor: AppColors.textPrimary,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
      ),
      splashFactory: NoSplash.splashFactory,
    );
  }
}
