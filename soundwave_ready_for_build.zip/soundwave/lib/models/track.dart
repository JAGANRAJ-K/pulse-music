class Track {
  final String id;
  final String title;
  final String artistName;
  final String albumName;
  final String imageUrl;
  final String streamUrl; // highest quality Jamendo offers for this track
  final int durationSeconds;
  final DateTime? releaseDate;

  Track({
    required this.id,
    required this.title,
    required this.artistName,
    required this.albumName,
    required this.imageUrl,
    required this.streamUrl,
    required this.durationSeconds,
    this.releaseDate,
  });

  factory Track.fromJamendo(Map<String, dynamic> json) {
    return Track(
      id: json['id']?.toString() ?? '',
      title: (json['name'] ?? 'Unknown Title').toString(),
      artistName: (json['artist_name'] ?? 'Unknown Artist').toString(),
      albumName: (json['album_name'] ?? '').toString(),
      imageUrl: (json['album_image'] ?? json['image'] ?? '').toString(),
      // audiodownload gives the best-quality file Jamendo has for the track;
      // requested with audioformat=flac (falls back to mp32 if flac unavailable).
      streamUrl: (json['audiodownload']?.toString().isNotEmpty == true)
          ? json['audiodownload']
          : (json['audio'] ?? '').toString(),
      durationSeconds: (json['duration'] is int)
          ? json['duration']
          : int.tryParse(json['duration']?.toString() ?? '0') ?? 0,
      releaseDate: DateTime.tryParse(json['releasedate']?.toString() ?? ''),
    );
  }

  String get durationLabel {
    final d = Duration(seconds: durationSeconds);
    final m = d.inMinutes.toString();
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}
