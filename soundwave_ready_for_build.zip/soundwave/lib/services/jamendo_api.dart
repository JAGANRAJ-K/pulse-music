import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/track.dart';

class JamendoApi {
  // The Client ID is a public mobile-app identifier. Prefer supplying it at
  // build time with --dart-define=JAMENDO_CLIENT_ID=... .
  static const String clientId = String.fromEnvironment(
    'JAMENDO_CLIENT_ID',
    defaultValue: 'ae5f7d10',
  );
  static const String _base = 'https://api.jamendo.com/v3.0';

  Future<List<Track>> _get(Map<String, String> params) async {
    final query = {
      'client_id': clientId,
      'format': 'json',
      'audioformat': 'flac',
      ...params,
    };
    final uri = Uri.parse('$_base/tracks/').replace(queryParameters: query);
    final res = await http.get(uri).timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) {
      throw Exception('Jamendo API error: ${res.statusCode}');
    }
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    final results = (data['results'] as List<dynamic>? ?? []);
    return results
        .map((e) => Track.fromJamendo(e as Map<String, dynamic>))
        .where((t) => t.streamUrl.isNotEmpty)
        .toList();
  }

  Future<List<Track>> fetchNewReleases({int limit = 40}) => _get({
        'order': 'releasedate_desc',
        'limit': '$limit',
      });

  Future<List<Track>> fetchPopular({int limit = 40}) => _get({
        'order': 'popularity_total',
        'limit': '$limit',
      });

  Future<List<Track>> search(String query, {int limit = 30}) {
    if (query.trim().isEmpty) return Future.value([]);
    return _get({'search': query.trim(), 'limit': '$limit'});
  }

  Future<List<Track>> fetchByTag(String tag, {int limit = 30}) => _get({
        'tags': tag,
        'limit': '$limit',
        'order': 'popularity_total',
      });
}
