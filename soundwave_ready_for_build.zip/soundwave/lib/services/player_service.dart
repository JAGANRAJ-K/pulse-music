import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import '../models/track.dart';

/// Central playback engine. Kept as a ChangeNotifier so any screen can
/// listen to "what's playing / is it playing / progress" without plumbing.
class PlayerService extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();
  final List<Track> _queue = [];
  int _currentIndex = -1;
  bool _isBuffering = false;

  AudioPlayer get rawPlayer => _player;
  Track? get currentTrack => (_currentIndex >= 0 && _currentIndex < _queue.length) ? _queue[_currentIndex] : null;
  bool get isPlaying => _player.playing;
  bool get isBuffering => _isBuffering;
  List<Track> get queue => List.unmodifiable(_queue);
  Stream<Duration> get positionStream => _player.positionStream;
  Duration get duration => _player.duration ?? Duration.zero;

  PlayerService() {
    _player.playerStateStream.listen((state) {
      _isBuffering = state.processingState == ProcessingState.loading ||
          state.processingState == ProcessingState.buffering;
      if (state.processingState == ProcessingState.completed) {
        playNext();
      }
      notifyListeners();
    });
  }

  Future<void> playTrack(Track track, {List<Track>? queueContext}) async {
    if (queueContext != null) {
      _queue
        ..clear()
        ..addAll(queueContext);
      _currentIndex = _queue.indexWhere((t) => t.id == track.id);
    } else {
      _queue.add(track);
      _currentIndex = _queue.length - 1;
    }
    await _playCurrent();
  }

  Future<void> _playCurrent() async {
    final track = currentTrack;
    if (track == null) return;
    try {
      _isBuffering = true;
      notifyListeners();
      await _player.setUrl(track.streamUrl);
      await _player.play();
    } catch (e) {
      debugPrint('Playback error: $e');
    } finally {
      _isBuffering = false;
      notifyListeners();
    }
  }

  Future<void> togglePlayPause() async {
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
    notifyListeners();
  }

  Future<void> playNext() async {
    if (_currentIndex + 1 < _queue.length) {
      _currentIndex++;
      await _playCurrent();
    }
  }

  Future<void> playPrevious() async {
    if (_currentIndex > 0) {
      _currentIndex--;
      await _playCurrent();
    }
  }

  Future<void> seek(Duration position) => _player.seek(position);

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
