# Build Pulse Music APK from an Android phone

## Easiest route: GitHub Actions

This project includes `.github/workflows/build-apk.yml`. It can generate the missing Android/Flutter scaffolding, run `flutter pub get`, run `flutter analyze`, and build a release APK in GitHub's cloud.

### Steps
1. Create a GitHub repository in your phone browser.
2. Extract this ZIP on your phone.
3. Upload the project files/folders to the repository (the repository root must contain `pubspec.yaml`, `lib/`, and `scripts/`).
4. In GitHub, open **Settings → Secrets and variables → Actions → New repository secret**.
5. Create `JAMENDO_CLIENT_ID` with your Jamendo Client ID.
6. Open **Actions → Build Pulse Music APK → Run workflow**.
7. When it finishes, open the workflow run and download the `pulse-music-release-apk` artifact.
8. On Android, allow installation from the browser/file manager if Android asks, then install the APK.

## If you have a PC
Install Flutter, then run:

```bash
flutter pub get
flutter analyze
flutter build apk --release --dart-define=JAMENDO_CLIENT_ID=YOUR_CLIENT_ID
```

The APK is generated at:
`build/app/outputs/flutter-apk/app-release.apk`

## Important
The Jamendo Client ID is a client identifier and is not a secret credential. Do not put a private server key or password in the mobile app.
