#!/usr/bin/env bash
set -euo pipefail

# Generate missing Flutter/Android scaffolding without replacing lib/ or pubspec.yaml.
flutter create --platforms=android --org com.soundwave .

MANIFEST="android/app/src/main/AndroidManifest.xml"
if ! grep -q 'android.permission.INTERNET' "$MANIFEST"; then
  python3 - "$MANIFEST" <<'PY'
import sys
p=sys.argv[1]
s=open(p, encoding='utf-8').read()
needle='<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
if needle in s:
    s=s.replace(needle, needle+'\n    <uses-permission android:name="android.permission.INTERNET"/>', 1)
open(p,'w',encoding='utf-8').write(s)
PY
fi
